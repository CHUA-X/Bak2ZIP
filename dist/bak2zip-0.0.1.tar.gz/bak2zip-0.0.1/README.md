﻿# English introduction
Bak2ZIP —— Backup all your important files with one click, say goodbye to lose your important files!

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# 中文介绍
Bak2ZIP ——一键备份你的所有重要文件，让你不再为丢失文件而烦恼！

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# 用法
> `import bak2zip`
> 
> `bak2zip.bak('指定的目录')`

- - - - - - - - - - - - - - - - - - - - - - - - - - - -

# bug反馈
### 如您在使用中发现任何问题，请访问作者[GitHub](https://github.com/CHUA-X/Bak2ZIP/issues "作者的GitHub")留言反馈，谢谢！